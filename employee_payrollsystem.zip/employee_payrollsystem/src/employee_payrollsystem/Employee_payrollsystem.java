/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package employee_payrollsystem;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author mseww
 */

public class Employee_payrollsystem extends Application {
    
    //@Override
    private TextField nameField;
    private TextField positionField;
    private TextField hrateField;
    private TextField totalhField;
    private TextField idField;
    private TextField taxField;
    private TextField allowField;
    private TextField bonusField;
    private TextField deductField;
    private TextArea salaryTotalTextArea;
     
    public void start(Stage primaryStage) {
        nameField = new TextField();
        nameField.setPromptText("Enter Name");
        idField = new TextField();
        idField.setPromptText("Enter Name");
        hrateField = new TextField();
        hrateField.setPromptText("Enter Hour Paying Rate");
        totalhField = new TextField();
        totalhField.setPromptText("Enter Total worked hours");
        positionField = new TextField();
        positionField.setPromptText("Enter Your Position");
        taxField = new TextField();
        taxField.setPromptText("Enter Tax Rate");
        allowField = new TextField();
        allowField.setPromptText("Enter your allownces");
        bonusField = new TextField();
        bonusField.setPromptText("Enter your bonuse");
        deductField = new TextField();
        deductField.setPromptText("Enter Your Deductions");
        salaryTotalTextArea = new TextArea();
        salaryTotalTextArea.setEditable(false);
        salaryTotalTextArea.setPromptText("Your Salary details will be shown here");


// Create buttons
Button addButton = new Button("Calculate Salary");
addButton.setOnAction(event -> calSalary());


// Create layout
GridPane gridPane = new GridPane();
gridPane.setPadding(new Insets(10));
gridPane.setHgap(10);
gridPane.setVgap(10);
gridPane.add(new Label("Name:"), 0, 1);
gridPane.add(nameField, 1, 1);
gridPane.add(new Label("Employee ID:"), 0, 2);
gridPane.add(idField, 1, 2);
gridPane.add(new Label("Your Position:"), 0, 3);
gridPane.add(positionField, 1, 3);
gridPane.add(new Label("Worked Hours:"), 0, 4);
gridPane.add(totalhField, 1, 4);
gridPane.add(new Label("Hour Rate:"), 0, 5);
gridPane.add(hrateField, 1, 5);
gridPane.add(new Label("Allowences:"), 0, 6);
gridPane.add(allowField, 1, 6);
gridPane.add(new Label("Bonuses:"), 0, 7);
gridPane.add(bonusField, 1, 7);
gridPane.add(new Label("Tax Rate:"), 0, 8);
gridPane.add(taxField, 1, 8);
gridPane.add(new Label("Total Deductions:"), 0, 9);
gridPane.add(deductField, 1, 9);
gridPane.add(addButton, 0, 10);

gridPane.add(salaryTotalTextArea, 1, 10);


// Show scene
Scene scene = new Scene(gridPane);
primaryStage.setScene(scene);
primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private void calSalary() {
    try {
        String name = nameField.getText();
        int employeeID = Integer.parseInt(idField.getText());
        String position = positionField.getText();
        double totalHours = Double.parseDouble(totalhField.getText());
        double hourRate = Double.parseDouble(hrateField.getText());
        double allowances = Double.parseDouble(allowField.getText());
        double bonuses = Double.parseDouble(bonusField.getText());
        double taxRate = Double.parseDouble(taxField.getText());
        double deductions = Double.parseDouble(deductField.getText());

        double basicSalary = totalHours * hourRate;
        double totalAllowances = basicSalary + allowances;
        double totalBonuses = totalAllowances + bonuses ;
        double totalTax = basicSalary * (taxRate / 100);
        double totalDeductions = deductions;

        double netSalary = (basicSalary + allowances + bonuses) - (totalTax + totalDeductions);

        // Update the salaryTotalTextArea to display the calculated salary details
            salaryTotalTextArea.setText("Name: " + name + "\nEmployee ID: " + employeeID + "\nPosition: " + position + 
                "\nBasic Salary: Rs. " + basicSalary + "\nTotal Allowances: Rs. " + totalAllowances +
                "\nTotal Bonuses: Rs. " + totalBonuses + "\nTotal Tax: Rs. " + totalTax +
                "\nTotal Deductions: Rs. " + totalDeductions + "\nNet Salary: Rs. " + netSalary);
        
    } catch (NumberFormatException e) {
        salaryTotalTextArea.setText("Invalid input. Please enter numeric values for calculations.");
        }
}

    

    
    
}
